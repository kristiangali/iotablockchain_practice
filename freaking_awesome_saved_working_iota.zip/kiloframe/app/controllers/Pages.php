<?php
    class Pages extends Controller {
        public function __construct(){
            
            $this->postModel = $this->model('Post');
            $this->userModel = $this->model('User');
            $this->walletModel = $this->model('Wallet');
        }

        public function index(){
            if(isLoggedIn()){
                redirect('posts');
            }

            $data = [
                'title' => 'KiloFrame',
                'description' => 'The beginning of custom development for 2020'
            ];

            $this->view('pages/index', $data);
        }
        public function wallet(){
            if(isLoggedIn()){
                redirect('wallets');
            }

            $data = [
                'title' => 'My Wallet Info',
                'description' => 'Wallet Info.'
            ];

            $this->view('pages/wallet', $data);
        }
        public function about(){
            $data = [
                'title' => 'About Us',
                'description' => 'App to share posts with other users'
            ];
            
            $this->view('pages/about', $data);
        }
        public function browse(){
            // Get posts
            $posts = $this->postModel->getPosts();

            $data = [
                'content' => $posts
            ];

            $this->view('pages/browse', $data);
        }
    }