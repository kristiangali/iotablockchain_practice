<?php
    class Wallets extends Controller {

        public function __construct(){
            if(!isLoggedIn()){
                redirect('users/login'); 
            }
            $this->walletModel = $this->model('Wallet');
            $this->userModel = $this->model('User');
        }
        
    
        public function index(){
            // Get posts
            $wallets = $this->walletModel->getWallets();

            $data = [
                'wallets' => $wallets
            ];

            $this->view('wallets/index', $data);
        }
        public function nodeinfo(){
            // Get posts
            $nodeinfo = $this->model('Wallet')->getNodeInfo();

            $data = [
                'nodeinfo' => $nodeinfo
            ];

            $this->view('wallets/nodeinfo', $data);
        }
        
    }

?>