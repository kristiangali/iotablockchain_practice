<?php
class Wallet {
        private $db;
        public $start;

        public function __construct(){
            $this->db = new Database;
        }

        public function getWallets(){
            $this->db->query('SELECT *, 
                                wallets.id as walletId,
                                users.id as userId,
                                wallets.created_at as walletCreated,
                                users.created_at as userCreated
                                FROM wallets
                                INNER JOIN users
                                ON wallets.user_id = users.id
                                ORDER BY wallets.created_at DESC
                            ');

            $results = $this->db->resultSet();

            return $results;
        }
        public function getNodeInfo() {
           return $this->db->connectToIota(true);
        }
    }
