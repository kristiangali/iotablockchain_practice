<?php require APPROOT . '/views/inc/header.php'; ?> 
<div class="container">

<?php foreach($data['content'] as $content) : ?>

        <div class="card card-body mb-3">
            <h4 class="card-title"><?php echo $content->title; ?></h4>
            <div class="bg-light p-2 mb-3">
                Written by <?php echo $content->name; ?> on <?php echo $content->postCreated; ?>
            </div>
            <div class="card-text"><?php echo $content->body; ?></div>
            <a href="<?php echo URLROOT; ?>/posts/show/<?php echo $content->postId; ?>" class="btn btn-dark">More</a>
        </div>
    <?php endforeach; ?>

</div>    
<?php require APPROOT . '/views/inc/footer.php';?>