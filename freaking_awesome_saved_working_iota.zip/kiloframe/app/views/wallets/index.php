<?php require APPROOT . '/views/inc/header.php'; ?>
<?php
echo '<pre>';
print_r($data);
echo '<pre>';
?>
<?php require APPROOT . '/views/inc/footer.php'; ?>