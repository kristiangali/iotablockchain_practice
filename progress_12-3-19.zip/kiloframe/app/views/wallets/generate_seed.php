<?php require APPROOT . '/views/inc/blockchain_header.php'; 
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<div class="container">
    <div class="row">
    <div class="col-md">
        New Seed For <?= $_SESSION['user_name']; ?><hr>
        <form id="encryptSave" action='<?= URLROOT; ?>/wallets/generate_address'>
            <input type="hidden" name='new_<?= $_SESSION['user_id']?>_seed' value='<?= $data['new_seed'];?>' />
            <input type="hidden" name='user_id' value="<?= $_SESSION['user_id']; ?>" />
            <input type="hidden" name='user_name' value="<?= $_SESSION['user_name']; ?>" />
            <input type="hidden" name='type' value="devnet" />
            <input type="hidden" name='token' value="<?= trim($_SESSION['csrf_token'] . '_' .$_SESSION['user_id']);?>" />
            <input class="btn btn-success" type='submit' value="Encrypt & Save New Private Seed">
        </form>
    </div>
    <div class="col-md">
        <div class="alert alert-danger">
           <h4>Do not share this private seed with anyone!</h4>
           <p>Please write this seed down.</p>
        </div>
        <textarea class="form-control" rows="3" disabled>
            <?= $data['new_seed']; ?>
        </textarea>
    </div>
    </div>
</div>
<?php require APPROOT . '/views/inc/blockchain_footer.php'; ?>