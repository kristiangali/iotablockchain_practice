<?php require APPROOT . '/views/inc/blockchain_header.php'; ?>
<?php  $ndata = json_decode($data["nodeinfo"], true); ?>
<div class="row">
<div class="col-lg">
    <center><h2>Current Iota Node Information</h2></center>
</div>
</div>
<div class="row">
        <div class="col-md">
         <div class="alert alert-success">
            <strong>Iota Node Type</strong>
            <hr>
            <?= $ndata["appName"]; ?>
        </div>
        </div>
        <div class="col-md">
          <div class="alert alert-success">
            <strong>Latest Release</strong>
            <hr>
            <?= $ndata["appVersion"]; ?>
        </div>
        </div>
        <div class="col-md">
        <div class="alert alert-success">
            <strong># of Processors</strong>
            <hr>
            <?= $ndata["jreAvailableProcessors"]; ?>
        </div>
        </div>
</div>
<div class="row">
        <div class="col-md">
         <div class="alert alert-info">
            <strong>Latest Block Address</strong>
            <hr>
            <?= $ndata["latestMilestone"]; ?>
        </div>
        </div>
        <div class="col-md">
          <div class="alert alert-info">
            <strong>Total # of Blocks on <?= $ndata["appName"]; ?></strong>
            <hr>
            <?= number_format($ndata["latestMilestoneIndex"], 0); ?>
        </div>
        </div>
        <div class="col-md">
        <div class="alert alert-warning">
            <strong>Retrieval Timestamp</strong>
            <hr>
            <?= $ndata["time"]; ?>
        </div>
        </div>
</div>
<?php require APPROOT . '/views/inc/blockchain_footer.php'; ?>