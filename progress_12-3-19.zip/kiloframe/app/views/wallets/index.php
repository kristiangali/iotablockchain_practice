<?php require APPROOT . '/views/inc/header.php'; ?>
<div class="container">
<div class="row">
    <?php
    echo "<pre>";
    print_r($data);
    echo "</pre>";
    
    echo "<div class='col-lg'><hr>";
    echo '<a class="btn btn-info" href="'.URLROOT.'/wallets/generate_seed">GENERATE WALLET SEED</a>';
    echo "</div><hr>";
    ?>
    </div>
</div>
<?php require APPROOT . '/views/inc/footer.php'; ?>