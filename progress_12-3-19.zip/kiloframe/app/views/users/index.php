<?php require APPROOT . '/views/inc/header.php'; ?>
<div class="container">
    <div class="jumbotron">
            <h1><?= $_SESSION['user_name']; ?>'s Profile Dashboard</h1>
            <hr>
            
    </div>
</div>
<?php require APPROOT . '/views/inc/footer.php'; ?>