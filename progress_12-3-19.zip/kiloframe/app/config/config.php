<?php
    // DB params
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'kiloframe');

    // App Root
    define('APPROOT', dirname(dirname(__FILE__)));
    
    // URL Root
    define('URLROOT', 'http://localhost/kiloframe');
    
    // Site Name
    define('SITENAME', 'KiloFrame');

    // App Version
    define('APPVERSION' , '1.0.0');