<?php
    class Wallets extends Controller {

        public function __construct(){
            if(!isLoggedIn()){
                redirect('users/login'); 
            }
            $this->walletModel = $this->model('Wallet');
            $this->userModel = $this->model('User');
        }
        
    
        public function index(){
            // Get posts
            $wallets = $this->walletModel->getWallets();

            $data = [
                'wallets' => $wallets
            ];

            $this->view('wallets/index', $data);
        }
        public function nodeinfo(){
            // Get posts
            $nodeinfo = $this->model('Wallet')->getNodeInfo();

            $data = [
                'nodeinfo' => $nodeinfo
            ];

            $this->view('wallets/nodeinfo', $data);
        }
        public function generate_seed() {
            $characters = '9ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';
            for ($i = 0; $i < 81; $i++) {
                $charlength = $charactersLength - 1;
                $randomString .=  $characters[rand(0, $charlength)];
            }
            $data = [
                'new_seed' => strtoupper($randomString)
            ];

            $this->view('wallets/generate_seed', $data);
        }
        public function generate_address() {
            if(isset($_SESSION['csrf_token']) && isset($_REQUEST['token']) && $_REQUEST['token'] == trim($_SESSION['csrf_token'].'_'.$_SESSION['user_id']) && isset($_REQUEST['new_'.$_SESSION['user_id'].'_seed'])) {
                $data['user_id'] = trim($_SESSION['user_id']);
                $data['type'] = trim($_REQUEST['type']);
                //should be the value of the seed.
                $data['seed'] = trim($_REQUEST['new_'.$_SESSION['user_id'].'_seed']);
            } else {
                $data['user_id'] = trim($_SESSION['user_id']);
                $data['type'] = 'security_failure';
                $data['seed'] = 'security failure breach seed was not successfully saved. Please regenerate seed.';
            }
            $new_wallet = $this->model('Wallet')->registerWallet($data);
            $data = json_encode($new_wallet);
            $this->view('wallets/generate_address', $data);
        }
        
    }

?>